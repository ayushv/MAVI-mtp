#include <Eigen/Core>
#include <Eigen/Array>
#include <Eigen/LU>
#include <Eigen/Cholesky>
#include <Eigen/Geometry>

using namespace Eigen;
using namespace std;

int main(int, char**)
{
  cout << RowVectorXi::Zero(4) << endl;
cout << VectorXf::Zero(2) << endl;

  return 0;
}
